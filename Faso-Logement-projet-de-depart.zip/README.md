# Faso Logement — première base Android

Projet Android natif Kotlin/Jetpack Compose, avec une interface de départ et une compilation APK via GitHub Actions.

## Contenu
- Interface Faso Logement
- Liste de logements d'exemple et filtre par quartier
- Écran d'information pour la publication
- Workflow GitHub Actions pour générer un APK debug

## Important
Les logements affichés sont des exemples. La connexion Firebase et la publication réelle d'annonces ne sont pas encore activées. Il faudra ajouter la configuration Firebase du projet pour rendre les annonces partagées et persistantes.

## Compilation
Sur GitHub : ouvrir l'onglet **Actions**, choisir **Build Faso Logement APK**, puis **Run workflow**. À la fin, récupérer l'artifact `Faso-Logement-debug-apk`.
