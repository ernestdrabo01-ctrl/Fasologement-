package com.fasologement.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Logement(val titre: String, val quartier: String, val prix: String, val details: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                FasoLogementApp()
            }
        }
    }
}

@Composable
fun FasoLogementApp() {
    val logements = listOf(
        Logement("Chambre-salon", "Karpala, Ouagadougou", "35 000 F CFA / mois", "Douche interne • Visite à organiser"),
        Logement("Studio", "Songnaba, Ouagadougou", "40 000 F CFA / mois", "Cuisine • Accès facile"),
        Logement("Chambre simple", "Kouritenga, Ouagadougou", "25 000 F CFA / mois", "Cour commune • Disponible")
    )
    var recherche by remember { mutableStateOf("") }
    var afficherFormulaire by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Faso Logement") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { afficherFormulaire = !afficherFormulaire }) {
                Text("+")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Trouve ton prochain logement au Burkina Faso", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = recherche, onValueChange = { recherche = it },
                label = { Text("Rechercher un quartier") }, modifier = Modifier.fillMaxWidth()
            )
            if (afficherFormulaire) {
                Spacer(Modifier.height(12.dp))
                Text("Pour publier une annonce, prépare les informations du logement : quartier, prix, type et contact.")
                Text("La publication en ligne sera activée après la connexion à Firebase.")
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(logements.filter { it.quartier.contains(recherche, ignoreCase = true) || recherche.isBlank() }) { logement ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(logement.titre, style = MaterialTheme.typography.titleMedium)
                            Text(logement.quartier)
                            Text(logement.prix, style = MaterialTheme.typography.titleSmall)
                            Text(logement.details)
                        }
                    }
                }
            }
        }
    }
}
